<template>
  <v-container>
    <h1>Welcome to Astrake EMS</h1>
    <p>Select a module from the sidebar.</p>
  </v-container>
</template>
